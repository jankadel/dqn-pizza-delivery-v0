from setuptools import setup

setup(name='gym_pizza_delivery',
      version='1.0.0',
      install_requires=['gym', 'numpy', 'pygame']
)

# pip install -e .